/**
 * وحدة واجهة المستخدم - يتعامل مع كل تفاعلات المستخدم والعرض
 */
const UI = (function() {
    // ترجمات
    const translations = {
        ar: {
            home: 'الرئيسية',
            browse: 'تصفح العناصر',
            reportLost: 'الإبلاغ عن عنصر مفقود',
            reportFound: 'الإبلاغ عن عنصر وجدته',
            categories: {
                electronics: 'إلكترونيات',
                documents: 'وثائق',
                wallets: 'محافظ',
                keys: 'مفاتيح',
                clothing: 'ملابس/إكسسوارات',
                books: 'كتب/قرطاسية',
                other: 'أخرى'
            },
            locations: {
                library: 'المكتبة',
                cafeteria: 'الكافتيريا',
                gym: 'صالة الألعاب الرياضية',
                lecture_hall: 'قاعة المحاضرات',
                parking: 'موقف السيارات',
                dorm: 'السكن الجامعي',
                admin: 'مبنى الإدارة',
                other: 'أخرى'
            },
            noItems: 'لا توجد عناصر للعرض حاليًا.',
            addNewItem: 'قم بإضافة عنصر جديد باستخدام الأزرار في الصفحة الرئيسية.',
            lost: 'مفقود',
            found: 'موجود',
            date: 'التاريخ',
            time: 'الوقت',
            lostDate: 'تاريخ الفقدان',
            foundDate: 'تاريخ العثور',
            successItemAdded: 'تم إضافة العنصر بنجاح',
            errorAddingItem: 'حدث خطأ أثناء إضافة العنصر',
            itemUpdated: 'تم تحديث العنصر بنجاح',
            itemDeleted: 'تم حذف العنصر بنجاح',
            itemMarkedAsFound: 'تم تحديث العنصر كموجود',
            itemMarkedAsReturned: 'تم تحديث العنصر كمسترجع',
            confirmDelete: 'هل أنت متأكد من أنك تريد حذف هذا العنصر؟',
            noMatches: 'لا توجد عناصر تطابق معايير البحث الخاصة بك.',
            resetFilters: 'حاول تغيير الفلاتر أو إعادة تعيينها.',
            switchToEnglish: 'English',
            switchToArabic: 'العربية',
            itemDetails: 'تفاصيل العنصر',
            category: 'الفئة',
            location: 'الموقع',
            description: 'الوصف',
            contactInfo: 'معلومات التواصل',
            backToList: 'العودة إلى قائمة العناصر',
            removeItem: 'حذف العنصر',
            markAsFound: 'تحديد كموجود',
            markAsReturned: 'تحديد كمسترجع',
            lostTips: [
                'تحقق من مكتب الأمانات في الحرم الجامعي.',
                'تفقد آخر الأماكن التي زرتها في ذلك اليوم.',
                'تواصل مع زملاء الدراسة الذين كانوا معك.',
                'راقب الإشعارات لأي تطابقات جديدة.'
            ],
            foundTips: [
                'يمكنك تسليم العنصر إلى مكتب الأمانات في الحرم الجامعي.',
                'احتفظ بالعنصر في مكان آمن حتى يتم التواصل مع المالك.',
                'تأكد من التحقق من هوية الشخص الذي يدعي ملكية العنصر.',
                'قم بتحديث حالة العنصر بمجرد إرجاعه للمالك.'
            ]
        },
        en: {
            home: 'Home',
            browse: 'Browse Items',
            reportLost: 'Report Lost Item',
            reportFound: 'Report Found Item',
            categories: {
                electronics: 'Electronics',
                documents: 'Documents',
                wallets: 'Wallets',
                keys: 'Keys',
                clothing: 'Clothing/Accessories',
                books: 'Books/Stationery',
                other: 'Other'
            },
            locations: {
                library: 'Library',
                cafeteria: 'Cafeteria',
                gym: 'Gym',
                lecture_hall: 'Lecture Hall',
                parking: 'Parking',
                dorm: 'Dormitory',
                admin: 'Administration Building',
                other: 'Other'
            },
            noItems: 'No items to display.',
            addNewItem: 'Add a new item using the buttons on the home page.',
            lost: 'Lost',
            found: 'Found',
            date: 'Date',
            time: 'Time',
            lostDate: 'Lost Date',
            foundDate: 'Found Date',
            successItemAdded: 'Item added successfully',
            errorAddingItem: 'Error adding item',
            itemUpdated: 'Item updated successfully',
            itemDeleted: 'Item deleted successfully',
            itemMarkedAsFound: 'Item marked as found',
            itemMarkedAsReturned: 'Item marked as returned',
            confirmDelete: 'Are you sure you want to delete this item?',
            noMatches: 'No items match your search criteria.',
            resetFilters: 'Try changing the filters or resetting them.',
            switchToEnglish: 'English',
            switchToArabic: 'العربية',
            itemDetails: 'Item Details',
            category: 'Category',
            location: 'Location',
            description: 'Description',
            contactInfo: 'Contact Information',
            backToList: 'Back to Items List',
            removeItem: 'Remove Item',
            markAsFound: 'Mark as Found',
            markAsReturned: 'Mark as Returned',
            lostTips: [
                'Check the campus lost and found office.',
                'Visit the last places you were at that day.',
                'Contact classmates who were with you.',
                'Watch for notifications for potential matches.'
            ],
            foundTips: [
                'You can deliver the item to the campus lost and found office.',
                'Keep the item in a safe place until the owner is contacted.',
                'Make sure to verify the identity of the person claiming ownership.',
                'Update the item status once it is returned to the owner.'
            ]
        }
    };
    
    // اللغة الحالية
    let currentLang = 'ar';
    
    /**
     * تهيئة واجهة المستخدم
     */
    function init() {
        setupEventListeners();
        updateCurrentYear();
        
        // تحديد اللغة المخزنة
        const savedLang = localStorage.getItem('lostFoundLanguage');
        if (savedLang) {
            setLanguage(savedLang);
        }
    }
    
    
    /**
     * إعداد مستمعي الأحداث
     */
    function setupEventListeners() {
        // مستمعي أحداث التنقل
        document.getElementById('nav-home').addEventListener('click', () => navigateToScreen('home-screen'));
        document.getElementById('nav-browse').addEventListener('click', () => navigateToScreen('browse-screen'));
        document.getElementById('language-toggle').addEventListener('click', toggleLanguage);
        document.getElementById('report-lost-btn').addEventListener('click', () => navigateToScreen('report-lost-screen'));
        document.getElementById('report-found-btn').addEventListener('click', () => navigateToScreen('report-found-screen'));
        document.getElementById('browse-btn').addEventListener('click', () => navigateToScreen('browse-screen'));
        
        // أزرار العودة
        document.querySelectorAll('.back-btn').forEach(btn => {
            btn.addEventListener('click', () => navigateToScreen('home-screen'));
        });
        
        // مستمعي أحداث النماذج
        document.getElementById('lost-form').addEventListener('submit', handleLostItemSubmit);
        document.getElementById('found-form').addEventListener('submit', handleFoundItemSubmit);
        document.getElementById('filter-form').addEventListener('submit', handleFilterSubmit);
        document.getElementById('reset-filters').addEventListener('click', resetFilters);
        
        // مستمعي أحداث تفاصيل العنصر
        document.querySelectorAll('.back-to-browse').forEach(btn => {
            btn.addEventListener('click', () => navigateToScreen('browse-screen'));
        });
        document.querySelectorAll('.back-to-home').forEach(btn => {
            btn.addEventListener('click', () => navigateToScreen('home-screen'));
        });
        
        // أزرار إجراءات العنصر
        document.getElementById('remove-item-btn').addEventListener('click', handleItemDelete);
        document.getElementById('mark-found-btn').addEventListener('click', handleMarkAsFound);
        document.getElementById('mark-returned-btn').addEventListener('click', handleMarkAsReturned);
        
        // تعيين التاريخ الحالي كقيمة افتراضية لحقول التاريخ
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('lost-date').value = today;
        document.getElementById('found-date').value = today;
    }
    
    /**
     * تحديث عام السنة الحالية في التذييل
     */
    function updateCurrentYear() {
        const currentYear = new Date().getFullYear();
        document.getElementById('current-year').textContent = currentYear;
    }
    
    /**
     * التنقل إلى شاشة محددة
     * @param {String} screenId - معرف الشاشة للانتقال إليها
     */
    function navigateToScreen(screenId) {
        // إخفاء جميع الشاشات
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        
        // عرض الشاشة المطلوبة
        document.getElementById(screenId).classList.add('active');
        
        // إجراءات إضافية عند الانتقال إلى شاشات معينة
        if (screenId === 'browse-screen') {
            loadItems();
        }
        
        // تحديث العنصر النشط في القائمة
        updateActiveNavItem(screenId);
        
        // التمرير إلى أعلى الصفحة
        window.scrollTo(0, 0);
    }
    
    /**
     * تحديث عنصر القائمة النشط
     * @param {String} screenId - معرف الشاشة النشطة
     */
    function updateActiveNavItem(screenId) {
        // إزالة الحالة النشطة من جميع عناصر القائمة
        document.querySelectorAll('.nav-link').forEach(item => {
            item.classList.remove('active');
        });
        
        // تعيين العنصر المناسب كنشط
        if (screenId === 'home-screen') {
            document.getElementById('nav-home').classList.add('active');
        } else if (screenId === 'browse-screen' || screenId === 'item-details-screen') {
            document.getElementById('nav-browse').classList.add('active');
        }
    }
    
    /**
     * تبديل بين اللغتين العربية والإنجليزية
     */
    function toggleLanguage() {
        const newLang = currentLang === 'ar' ? 'en' : 'ar';
        setLanguage(newLang);
    }
    
    /**
     * تعيين لغة التطبيق
     * @param {String} lang - رمز اللغة المراد تعيينها ('ar' أو 'en')
     */
    function setLanguage(lang) {
        if (lang !== 'ar' && lang !== 'en') return;
        
        currentLang = lang;
        
        // تحديث اتجاه الصفحة ولغتها
        document.documentElement.lang = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        
        // تخزين اللغة المحددة
        localStorage.setItem('lostFoundLanguage', lang);
        
        // تحديث نص زر تبديل اللغة
        document.getElementById('language-toggle').textContent = 
            lang === 'ar' ? translations.ar.switchToEnglish : translations.en.switchToArabic;
        
        // تحديث النصوص في واجهة المستخدم
        updateUITexts();
        
        // إعادة تحميل العناصر إذا كنا في شاشة التصفح
        if (document.getElementById('browse-screen').classList.contains('active')) {
            loadItems();
        }
    }
    
    /**
     * تحديث نصوص واجهة المستخدم حسب اللغة المحددة
     */
    function updateUITexts() {
        const t = translations[currentLang];
        
        // تحديث عناصر القائمة
        document.getElementById('nav-home').textContent = t.home;
        document.getElementById('nav-browse').textContent = t.browse;
        
        // تحديث الأزرار الرئيسية
        document.getElementById('report-lost-btn').textContent = t.reportLost;
        document.getElementById('report-found-btn').textContent = t.reportFound;
        document.getElementById('browse-btn').textContent = t.browse;
        
        // تحديث نصوص أخرى حسب الحاجة...
    }
    
    /**
     * عرض إشعار
     * @param {String} title - عنوان الإشعار
     * @param {String} message - رسالة الإشعار
     * @param {String} type - نوع الإشعار (success, danger, warning, info)
     */
    function showToast(title, message, type = 'info') {
        const container = document.getElementById('notification-container');
        
        // إنشاء عنصر الإشعار
        const toast = document.createElement('div');
        toast.className = `notification ${type}`;
        
        // تحديد الأيقونة حسب النوع
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'danger' || type === 'error') {
            icon = 'exclamation-circle';
            type = 'error';
        }
        if (type === 'warning') icon = 'exclamation-triangle';
        
        // إنشاء محتوى الإشعار
        toast.innerHTML = `
            <div class="notification-icon">
                <i class="bi bi-${icon}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-title">${title}</div>
                <div>${message}</div>
            </div>
            <div class="notification-close">
                <i class="bi bi-x"></i>
            </div>
        `;
        
        // إضافة الإشعار إلى الحاوية
        container.appendChild(toast);
        
        // إضافة مستمع حدث لزر الإغلاق
        toast.querySelector('.notification-close').addEventListener('click', () => {
            container.removeChild(toast);
        });
        
        // إزالة الإشعار تلقائيًا بعد 5 ثوانٍ
        setTimeout(() => {
            if (container.contains(toast)) {
                container.removeChild(toast);
            }
        }, 5000);
    }
    
    /**
     * التعامل مع تقديم نموذج العنصر المفقود
     * @param {Event} e - حدث التقديم
     */
    function handleLostItemSubmit(e) {
        e.preventDefault();
        
        // جمع بيانات النموذج
        const name = document.getElementById('lost-name').value;
        const category = document.getElementById('lost-category').value;
        const location = document.getElementById('lost-location').value;
        const lostDate = document.getElementById('lost-date').value;
        const lostTime = document.getElementById('lost-time').value;
        const description = document.getElementById('lost-description').value;
        const contact = document.getElementById('lost-contact').value;
        const imageInput = document.getElementById('lost-image');
        
        try {
            // تجهيز بيانات العنصر
            const itemData = {
                type: 'lost',
                name,
                category,
                location,
                lostDate,
                lostTime,
                description,
                contact,
                isFound: false,
                imageSrc: null
            };
            
            // التعامل مع الصورة إذا تم تحديدها
            if (imageInput.files && imageInput.files[0]) {
                const reader = new FileReader();
                reader.onload = function(fileEvent) {
                    itemData.imageSrc = fileEvent.target.result;
                    
                    // إضافة العنصر بعد معالجة الصورة
                    addItemAndShowNotification(itemData);
                };
                reader.readAsDataURL(imageInput.files[0]);
            } else {
                // إضافة العنصر بدون صورة
                addItemAndShowNotification(itemData);
            }
        } catch (error) {
            showToast(translations[currentLang].errorAddingItem, error.message, 'error');
        }
    }
    
    /**
     * التعامل مع تقديم نموذج العنصر الموجود
     * @param {Event} e - حدث التقديم
     */
    function handleFoundItemSubmit(e) {
        e.preventDefault();
        
        // جمع بيانات النموذج
        const name = document.getElementById('found-name').value;
        const category = document.getElementById('found-category').value;
        const location = document.getElementById('found-location').value;
        const foundDate = document.getElementById('found-date').value;
        const foundTime = document.getElementById('found-time').value;
        const description = document.getElementById('found-description').value;
        const contact = document.getElementById('found-contact').value;
        const imageInput = document.getElementById('found-image');
        
        try {
            // تجهيز بيانات العنصر
            const itemData = {
                type: 'found',
                name,
                category,
                location,
                foundDate,
                foundTime,
                description,
                contact,
                isReturned: false,
                imageSrc: null
            };
            
            // التعامل مع الصورة إذا تم تحديدها
            if (imageInput.files && imageInput.files[0]) {
                const reader = new FileReader();
                reader.onload = function(fileEvent) {
                    itemData.imageSrc = fileEvent.target.result;
                    
                    // إضافة العنصر بعد معالجة الصورة
                    addItemAndShowNotification(itemData);
                };
                reader.readAsDataURL(imageInput.files[0]);
            } else {
                // إضافة العنصر بدون صورة
                addItemAndShowNotification(itemData);
            }
        } catch (error) {
            showToast(translations[currentLang].errorAddingItem, error.message, 'error');
        }
    }
    
    /**
     * إضافة عنصر وعرض إشعار
     * @param {Object} itemData - بيانات العنصر
     */
    function addItemAndShowNotification(itemData) {
        // إضافة العنصر إلى التخزين
        const itemId = Storage.addItem(itemData);
        
        if (itemId) {
            const t = translations[currentLang];
            showToast(t.successItemAdded, '', 'success');
            
            // إعادة تعيين النموذج
            if (itemData.type === 'lost') {
                document.getElementById('lost-form').reset();
                document.getElementById('lost-date').value = new Date().toISOString().split('T')[0];
            } else {
                document.getElementById('found-form').reset();
                document.getElementById('found-date').value = new Date().toISOString().split('T')[0];
            }
            
            // التحقق من التطابقات المحتملة
            const potentialMatches = Storage.findPotentialMatches(itemData);
            if (potentialMatches.length > 0) {
                // في حالة وجود تطابقات، اعرض الإشعار وانتقل إلى شاشة التصفح
                const matchMessage = itemData.type === 'lost' 
                    ? 'وجدنا عناصر قد تطابق العنصر المفقود الخاص بك!'
                    : 'وجدنا عناصر مفقودة قد تطابق ما عثرت عليه!';
                
                showToast('تطابقات محتملة', matchMessage, 'info');
                setTimeout(() => {
                    navigateToScreen('browse-screen');
                }, 1000);
            } else {
                // في حالة عدم وجود تطابقات، انتقل إلى الشاشة الرئيسية
                setTimeout(() => {
                    navigateToScreen('home-screen');
                }, 1000);
            }
        } else {
            showToast(translations[currentLang].errorAddingItem, '', 'error');
        }
    }
    
    /**
     * تحميل وعرض العناصر حسب الفلاتر الحالية
     */
    function loadItems() {
        // الحصول على قيم الفلاتر
        const typeFilter = document.getElementById('filter-type').value;
        const categoryFilter = document.getElementById('filter-category').value;
        const locationFilter = document.getElementById('filter-location').value;
        const dateFilter = document.getElementById('filter-date').value;
        const queryFilter = document.getElementById('filter-query').value;
        
        // تطبيق الفلاتر
        const filters = {
            type: typeFilter,
            category: categoryFilter,
            location: locationFilter,
            date: dateFilter,
            query: queryFilter
        };
        
        const filteredItems = Storage.filterItems(filters);
        renderItems(filteredItems);
    }
    
    /**
     * عرض العناصر في شاشة التصفح
     * @param {Array} items - مصفوفة من العناصر للعرض
     */
    function renderItems(items) {
        const container = document.getElementById('items-container');
        const t = translations[currentLang];
        
        // مسح العناصر الحالية
        container.innerHTML = '';
        
        if (items.length === 0) {
            // عرض رسالة في حالة عدم وجود عناصر
            container.innerHTML = `
                <div class="col-12 text-center py-5 text-muted empty-state">
                    <i class="bi bi-search display-4"></i>
                    <p class="mt-3">${t.noMatches}</p>
                    <p>${t.resetFilters}</p>
                </div>
            `;
            return;
        }
        
        // إنشاء بطاقة لكل عنصر
        items.forEach(item => {
            const isLost = item.type === 'lost';
            const itemDate = isLost ? item.lostDate : item.foundDate;
            const itemTime = isLost ? item.lostTime : item.foundTime;
            const statusClass = isLost ? 'danger' : 'success';
            const statusText = isLost ? t.lost : t.found;
            const cardClass = isLost ? 'lost-item' : 'found-item';
            
            // ترجمة الفئة والموقع
            const categoryText = t.categories[item.category] || item.category;
            const locationText = t.locations[item.location] || item.location;
            
            const card = document.createElement('div');
            card.className = 'col-md-4 mb-4';
            card.innerHTML = `
                <div class="card h-100 item-card ${cardClass}">
                    ${item.imageSrc ? 
                        `<img src="${item.imageSrc}" alt="${item.name}" class="card-img-top item-image-thumbnail">` : 
                        `<div class="card-img-top bg-secondary text-center py-4">
                            <i class="bi bi-image text-white display-4"></i>
                        </div>`
                    }
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title">${item.name}</h5>
                            <span class="badge bg-${statusClass}">
                                ${statusText}
                            </span>
                        </div>
                        
                        <p class="card-text text-truncate mb-2">${item.description}</p>
                        
                        <div class="d-flex flex-wrap mb-2">
                            <div class="time-badge">
                                <i class="bi bi-tag"></i> ${categoryText}
                            </div>
                            <div class="time-badge">
                                <i class="bi bi-geo-alt"></i> ${locationText}
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <small class="text-muted">
                                <i class="bi bi-calendar"></i> ${formatDate(itemDate)}
                                ${itemTime ? `<i class="bi bi-clock ms-2"></i> ${itemTime}` : ''}
                            </small>
                        </div>
                        
                        <button class="btn btn-primary stretched-link view-item-btn" data-id="${item.id}">
                            ${t.itemDetails}
                        </button>
                    </div>
                </div>
            `;
            
            container.appendChild(card);
            
            // إضافة مستمع الحدث لعرض تفاصيل العنصر
            const viewBtn = card.querySelector('.view-item-btn');
            viewBtn.addEventListener('click', () => showItemDetails(item.id));
        });
    }
    
    /**
     * تنسيق التاريخ
     * @param {String} dateString - سلسلة التاريخ
     * @returns {String} التاريخ المنسق
     */
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString(currentLang === 'ar' ? 'ar-SA' : 'en-US');
    }
    
    /**
     * عرض تفاصيل العنصر
     * @param {String} itemId - معرف العنصر المراد عرض تفاصيله
     */
    function showItemDetails(itemId) {
        const item = Storage.getItemById(itemId);
        if (!item) return;
        
        const t = translations[currentLang];
        const isLost = item.type === 'lost';
        
        // تحديث معلومات التنقل
        document.getElementById('item-name-breadcrumb').textContent = item.name;
        
        // تحديث عنوان الصفحة والحالة
        document.getElementById('item-details-title').textContent = isLost ? t.reportLost : t.reportFound;
        document.getElementById('item-header').className = `card-header text-white d-flex justify-content-between align-items-center bg-${isLost ? 'danger' : 'success'}`;
        document.getElementById('item-status-badge').className = `badge bg-light text-${isLost ? 'danger' : 'success'}`;
        document.getElementById('item-status-badge').textContent = isLost ? t.lost : t.found;
        
        // تحديث تفاصيل العنصر
        document.getElementById('item-name-display').textContent = item.name;
        document.getElementById('item-description-display').textContent = item.description;
        
        // تحديث الفئة
        document.getElementById('category-text').textContent = t.categories[item.category] || item.category;
        document.getElementById('item-category-display').className = `time-badge category-${item.category}`;
        
        // تحديث الموقع
        document.getElementById('location-label').textContent = isLost ? t.location : t.location;
        document.getElementById('location-text').textContent = t.locations[item.location] || item.location;
        
        // تحديث التاريخ والوقت
        document.getElementById('date-label').textContent = isLost ? t.lostDate : t.foundDate;
        document.getElementById('date-text').textContent = formatDate(isLost ? item.lostDate : item.foundDate);
        
        if ((isLost && item.lostTime) || (!isLost && item.foundTime)) {
            document.getElementById('item-time-display').style.display = 'inline-block';
            document.getElementById('time-text').textContent = isLost ? item.lostTime : item.foundTime;
        } else {
            document.getElementById('item-time-display').style.display = 'none';
        }
        
        // تحديث معلومات التواصل
        document.getElementById('contact-info-display').textContent = item.contact;
        
        // تحديث الصورة
        const imageContainer = document.getElementById('item-image-container');
        imageContainer.innerHTML = '';
        
        if (item.imageSrc) {
            const img = document.createElement('img');
            img.src = item.imageSrc;
            img.alt = item.name;
            img.className = 'img-fluid item-image rounded';
            imageContainer.appendChild(img);
        } else {
            imageContainer.innerHTML = `
                <div class="text-center mb-3 p-5 bg-secondary bg-opacity-25 rounded">
                    <i class="bi bi-image display-1 text-muted"></i>
                    <p class="mt-3 text-muted">لا توجد صورة متاحة</p>
                </div>
            `;
        }
        
        // تحديث النصائح
        const tipsContainer = document.getElementById('tips-container');
        tipsContainer.innerHTML = '';
        
        const tips = isLost ? t.lostTips : t.foundTips;
        const tipsList = document.createElement('ul');
        tipsList.className = 'list-unstyled';
        
        tips.forEach(tip => {
            const li = document.createElement('li');
            li.className = 'mb-3';
            li.innerHTML = `<i class="bi bi-check-circle-fill text-success me-2"></i> ${tip}`;
            tipsList.appendChild(li);
        });
        
        tipsContainer.appendChild(tipsList);
        
        // تحديث أزرار الإجراءات
        const removeBtn = document.getElementById('remove-item-btn');
        const markFoundBtn = document.getElementById('mark-found-btn');
        const markReturnedBtn = document.getElementById('mark-returned-btn');
        
        removeBtn.style.display = 'inline-block';
        markFoundBtn.style.display = 'none';
        markReturnedBtn.style.display = 'none';
        
        // عرض زر تحديد كموجود للعناصر المفقودة التي لم يتم العثور عليها
        if (isLost && !item.isFound) {
            markFoundBtn.style.display = 'inline-block';
        }
        
        // عرض زر تحديد كمسترجع للعناصر الموجودة التي لم يتم إرجاعها
        if (!isLost && !item.isReturned) {
            markReturnedBtn.style.display = 'inline-block';
        }
        
        // تخزين معرف العنصر الحالي لاستخدامه في الإجراءات
        removeBtn.setAttribute('data-id', item.id);
        markFoundBtn.setAttribute('data-id', item.id);
        markReturnedBtn.setAttribute('data-id', item.id);
        
        // الانتقال إلى شاشة تفاصيل العنصر
        navigateToScreen('item-details-screen');
    }
    
    /**
     * التعامل مع تقديم نموذج الفلتر
     * @param {Event} e - حدث التقديم
     */
    function handleFilterSubmit(e) {
        e.preventDefault();
        loadItems();
    }
    
    /**
     * إعادة تعيين الفلاتر
     */
    function resetFilters() {
        document.getElementById('filter-type').value = 'all';
        document.getElementById('filter-category').value = 'all';
        document.getElementById('filter-location').value = 'all';
        document.getElementById('filter-date').value = '';
        document.getElementById('filter-query').value = '';
        
        loadItems();
    }
    
    /**
     * التعامل مع حذف عنصر
     */
    function handleItemDelete() {
        const t = translations[currentLang];
        const itemId = this.getAttribute('data-id');
        
        if (confirm(t.confirmDelete)) {
            if (Storage.deleteItem(itemId)) {
                showToast(t.itemDeleted, '', 'success');
                setTimeout(() => {
                    navigateToScreen('browse-screen');
                }, 1000);
            }
        }
    }
    
    /**
     * التعامل مع تحديد عنصر مفقود كموجود
     */
    function handleMarkAsFound() {
        const t = translations[currentLang];
        const itemId = this.getAttribute('data-id');
        
        if (Storage.updateItem(itemId, { isFound: true })) {
            showToast(t.itemMarkedAsFound, '', 'success');
            // تحديث الواجهة لعرض التغييرات
            showItemDetails(itemId);
        }
    }
    
    /**
     * التعامل مع تحديد عنصر موجود كمسترجع
     */
    function handleMarkAsReturned() {
        const t = translations[currentLang];
        const itemId = this.getAttribute('data-id');
        
        if (Storage.updateItem(itemId, { isReturned: true })) {
            showToast(t.itemMarkedAsReturned, '', 'success');
            // تحديث الواجهة لعرض التغييرات
            showItemDetails(itemId);
        }
    }
    
    // كشف الواجهة العامة
    return {
        init,
        showToast,
        navigateToScreen
    };

})();