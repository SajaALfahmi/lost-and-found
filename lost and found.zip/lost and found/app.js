/**
 * التطبيق الرئيسي - ينسق التفاعل بين واجهة المستخدم والتخزين
 */
document.addEventListener('DOMContentLoaded', function() {
    // تهيئة واجهة المستخدم
    UI.init();
});