
/**
 * وحدة التخزين - يتعامل مع تخزين البيانات في المتصفح المحلي (localStorage)
 */
const Storage = (function() {
    // اسم المفتاح المستخدم في localStorage
    const ITEMS_STORAGE_KEY = 'lostFoundItems';
    
    // العناصر الافتراضية التي ستظهر عند بدء التطبيق لأول مرة
    const DEFAULT_ITEMS = [
        {
            id: 'default-lost-1',
            type: 'lost',
            name: 'سماعات لاسلكية',
            category: 'electronics',
            location: 'library',
            lostDate: '2025-05-01',
            lostTime: '14:30',
            description: 'سماعات لاسلكية من نوع Airpods Pro سوداء اللون، مع علبتها. فقدتها في الطابق الثاني من المكتبة قرب قسم الكتب العلمية.',
            contact: '0555555555',
            isFound: false,
            createdAt: '2025-05-01T14:30:00.000Z'
        },
        {
            id: 'default-found-1',
            type: 'found',
            name: 'آيباد',
            category: 'electronics',
            location: 'lecture_hall',
            foundDate: '2025-05-03',
            foundTime: '10:15',
            description: 'آيباد من الجيل الثامن رمادي اللون، عليه غطاء أزرق. وجدته على طاولة في قاعة المحاضرات A103.',
            contact: '0566666666',
            isReturned: false,
            createdAt: '2025-05-03T10:15:00.000Z'
        },
        {
            id: 'default-found-2',
            type: 'found',
            name: 'بطاقة صراف',
            category: 'wallets',
            location: 'cafeteria',
            foundDate: '2025-05-05',
            foundTime: '12:45',
            description: 'بطاقة صراف لبنك الراجحي باسم "عبدالله". وجدتها على الطاولة بالقرب من المدخل في الكافتيريا.',
            contact: '0577777777',
            isReturned: false,
            createdAt: '2025-05-05T12:45:00.000Z'
        }
    ];
    
    /**
     * الحصول على جميع العناصر من التخزين المحلي
     * @returns {Array} مصفوفة من جميع العناصر
     */
    function getAllItems() {
        const itemsJSON = localStorage.getItem(ITEMS_STORAGE_KEY);
        // إذا لم تكن هناك عناصر مخزنة، قم بإنشاء العناصر الافتراضية
        if (!itemsJSON) {
            saveAllItems(DEFAULT_ITEMS);
            return DEFAULT_ITEMS;
        }
        return JSON.parse(itemsJSON);
    }
    
    /**
     * حفظ جميع العناصر في التخزين المحلي
     * @param {Array} items - مصفوفة العناصر المراد حفظها
     */
    function saveAllItems(items) {
        localStorage.setItem(ITEMS_STORAGE_KEY, JSON.stringify(items));
    }
    
    /**
     * إضافة عنصر جديد
     * @param {Object} item - العنصر المراد إضافته
     * @returns {String} معرّف العنصر المضاف
     */
    function addItem(item) {
        const items = getAllItems();
        const id = generateId();
        const createdAt = new Date().toISOString();
        
        // إضافة معرف وتاريخ الإنشاء
        const newItem = { ...item, id, createdAt };
        
        items.push(newItem);
        saveAllItems(items);
        
        return id;
    }
    
    /**
     * الحصول على عنصر بواسطة معرّفه
     * @param {String} id - معرّف العنصر
     * @returns {Object|null} العنصر أو null إذا لم يتم العثور عليه
     */
    function getItemById(id) {
        const items = getAllItems();
        return items.find(item => item.id === id) || null;
    }
    
    /**
     * حذف عنصر بواسطة معرّفه
     * @param {String} id - معرّف العنصر المراد حذفه
     * @returns {Boolean} true إذا تم الحذف، false إذا لم يتم العثور عليه
     */
    function deleteItem(id) {
        const items = getAllItems();
        const initialLength = items.length;
        const filteredItems = items.filter(item => item.id !== id);
        
        if (filteredItems.length < initialLength) {
            saveAllItems(filteredItems);
            return true;
        }
        
        return false;
    }
    
    /**
     * تحديث عنصر بواسطة معرّفه
     * @param {String} id - معرّف العنصر المراد تحديثه
     * @param {Object} updates - التحديثات المراد تطبيقها
     * @returns {Boolean} true إذا تم التحديث، false إذا لم يتم العثور عليه
     */
    function updateItem(id, updates) {
        const items = getAllItems();
        const itemIndex = items.findIndex(item => item.id === id);
        
        if (itemIndex !== -1) {
            items[itemIndex] = { ...items[itemIndex], ...updates, updatedAt: new Date().toISOString() };
            saveAllItems(items);
            return true;
        }
        
        return false;
    }
    
    /**
     * تصفية العناصر بناءً على معايير
     * @param {Object} filters - معايير التصفية
     * @returns {Array} العناصر المصفاة
     */
    function filterItems(filters = {}) {
        const items = getAllItems();
        
        return items.filter(item => {
            // تصفية حسب النوع (مفقود أو موجود)
            if (filters.type && filters.type !== 'all' && item.type !== filters.type) {
                return false;
            }
            
            // تصفية حسب الفئة
            if (filters.category && filters.category !== 'all' && item.category !== filters.category) {
                return false;
            }
            
            // تصفية حسب الموقع
            if (filters.location && filters.location !== 'all' && item.location !== filters.location) {
                return false;
            }
            
            // تصفية حسب التاريخ
            if (filters.date) {
                const filterDate = new Date(filters.date).setHours(0, 0, 0, 0);
                const itemDate = new Date(item.type === 'lost' ? item.lostDate : item.foundDate).setHours(0, 0, 0, 0);
                if (filterDate !== itemDate) {
                    return false;
                }
            }
            
            // تصفية حسب النص
            if (filters.query) {
                const query = filters.query.toLowerCase();
                const nameMatch = item.name.toLowerCase().includes(query);
                const descMatch = item.description.toLowerCase().includes(query);
                if (!nameMatch && !descMatch) {
                    return false;
                }
            }
            
            return true;
        });
    }
    
    /**
     * توليد معرّف فريد
     * @returns {String} معرّف فريد
     */
    function generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    }
    
    /**
     * حذف جميع العناصر من التخزين
     */
    function clearAllItems() {
        localStorage.removeItem(ITEMS_STORAGE_KEY);
    }
    
    /**
     * إيجاد عناصر قد تكون متطابقة
     * @param {Object} item - العنصر الذي نبحث عن تطابقات محتملة له
     * @returns {Array} مصفوفة من العناصر المتطابقة المحتملة
     */
    function findPotentialMatches(item) {
        const items = getAllItems();
        const isLostItem = item.type === 'lost';
        
        // نبحث عن عناصر مفقودة إذا كان العنصر الحالي موجودًا، والعكس صحيح
        const oppositeType = isLostItem ? 'found' : 'lost';
        
        return items.filter(otherItem => {
            // تأكد من أن النوع معاكس (مفقود/موجود)
            if (otherItem.type !== oppositeType) {
                return false;
            }
            
            // ابحث عن تطابق في الفئة
            if (item.category !== otherItem.category) {
                return false;
            }
            
            // ابحث عن تطابق في الموقع
            if (item.location !== otherItem.location) {
                return false;
            }
            
            // قارن التواريخ - إذا كان العنصر مفقودًا، فيجب أن يكون تاريخ الفقدان قبل تاريخ العثور
            if (isLostItem) {
                const lostDate = new Date(item.lostDate);
                const foundDate = new Date(otherItem.foundDate);
                if (lostDate > foundDate) {
                    return false;
                }
            } else {
                const lostDate = new Date(otherItem.lostDate);
                const foundDate = new Date(item.foundDate);
                if (lostDate > foundDate) {
                    return false;
                }
            }
            
            // قارن الأسماء والأوصاف لمعرفة ما إذا كانت متشابهة
            const itemNameLower = item.name.toLowerCase();
            const otherNameLower = otherItem.name.toLowerCase();
            const itemDescLower = item.description.toLowerCase();
            const otherDescLower = otherItem.description.toLowerCase();
            
            // تحقق من تطابق الاسم بشكل مباشر أو جزئي
            const nameMatch = itemNameLower.includes(otherNameLower) || otherNameLower.includes(itemNameLower);
            
            // تحقق من تطابق الوصف بشكل جزئي
            const descMatch = itemDescLower.includes(otherDescLower) || otherDescLower.includes(itemDescLower);
            
            return nameMatch || descMatch;
        });
    }
    
    // كشف الواجهة العامة
    return {
        getAllItems,
        addItem,
        getItemById,
        deleteItem,
        updateItem,
        filterItems,
        clearAllItems,
        findPotentialMatches
    };
})();